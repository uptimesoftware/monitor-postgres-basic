PostgreSQL Availability Plug-In Monitor

This plug-in monitor allows you to ensure that your PostgreSQL database is running. The monitor attempts to connect to your PostgreSQL database and run a test query.  The response can then be compared to a string you specify